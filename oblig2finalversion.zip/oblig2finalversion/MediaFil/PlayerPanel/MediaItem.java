package oblig2finalversion.MediaFil.PlayerPanel;

import java.nio.file.Path;
// Representerer et medieelement i spillelisten.

public class MediaItem {

    private final String displayName;
    private final Path filePath;

    public MediaItem(String displayName, Path filePath) {
        this.displayName = displayName;
        this.filePath = filePath;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Path getFilePath() {
        return filePath;
    }


    @Override
    public String toString() {
        return displayName;
    }
}