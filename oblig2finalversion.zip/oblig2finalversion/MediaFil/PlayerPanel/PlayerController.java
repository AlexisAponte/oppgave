package oblig2finalversion.MediaFil.PlayerPanel;

import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaException;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

// Kontroller for mediespilleren.
// Håndterer brukerinteraksjoner, medieavspilling og oppdatering av GUI-komponenter.
// og logikken for å spille av, pause, stoppe og navigere gjennom medieelementer i spillelisten.

public class PlayerController {

    private final PlayerLayout layout;
    // spillelisten som en liste av MediaItem-objekter
    private final List<MediaItem> playlist = new ArrayList<>();
    private MediaPlayer mediaPlayer;
    private int currentIndex = -1;
    private boolean isSeeking = false; // for å skille mellom auto-oppdatering og bruker-drag

    public PlayerController(PlayerLayout layout) {
        this.layout = layout;
    }

    public void init() {
        initPlaylist();
        initBindings();
        initEventHandlers();
    }

    
    private void initPlaylist() {

    // starter med en tom spilleliste
    layout.getPlaylistView().getItems().clear();
    playlist.clear();

    // Ingen valgt ennå
    currentIndex = -1;
    }


    private void initBindings() {

        layout.getVolumeSlider().valueProperty().addListener((obs, oldVal, newVal) -> {
            if (mediaPlayer != null) {
                mediaPlayer.setVolume(newVal.doubleValue());
            }
        });

        layout.getNowPlayingLabel().textProperty().bind(
                Bindings.createStringBinding(() -> {
                    MediaItem selected = layout.getPlaylistView()
                            .getSelectionModel()
                            .getSelectedItem();
                    if (selected == null) {
                        return "Now Playing: —";
                    }
                    return "Now Playing: " + selected.getDisplayName();
                }, layout.getPlaylistView().getSelectionModel().selectedItemProperty())
        );
      }

      //hendelser for knapper og interaksjoner
    private void initEventHandlers() {

        layout.getPlaylistView().getSelectionModel().selectedIndexProperty()
                .addListener((obs, oldIdx, newIdx) -> {
                    if (newIdx != null && newIdx.intValue() >= 0) {
                        currentIndex = newIdx.intValue();
                        playSelectedItem();
                    }
                });
        layout.getBtnImport().setOnAction(e -> openFileChooser());
        layout.getBtnPlay().setOnAction(e -> resume());
        layout.getBtnPause().setOnAction(e -> pause());
        layout.getBtnStop().setOnAction(e -> stop());
        layout.getBtnNext().setOnAction(e -> playNext());
        layout.getBtnPrev().setOnAction(e -> playPrevious());

        layout.getProgressSlider().valueChangingProperty().addListener((obs, wasChanging, isChanging) -> {
            isSeeking = isChanging;
            if (!isChanging && mediaPlayer != null) {
                double seconds = layout.getProgressSlider().getValue();
                mediaPlayer.seek(Duration.seconds(seconds));
            }
        });

        layout.getProgressSlider().setOnMouseReleased(e -> {
            if (mediaPlayer != null) {
                double seconds = layout.getProgressSlider().getValue();
                mediaPlayer.seek(Duration.seconds(seconds));
            }
        });
      }

     // spiller det valgte medieelementet
    private void playSelectedItem() {
        MediaItem selected = layout.getPlaylistView().getSelectionModel().getSelectedItem();
        if (selected == null) {
            return;
        }
        startMedia(selected);
        }
        // starter avspillingen av et medieelement
    private void startMedia(MediaItem item) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.dispose();
         }

        try {
            Path path = item.getFilePath();
            File file = path.toFile();
            String uri = file.toURI().toString();

            Media media = new Media(uri);
            mediaPlayer = new MediaPlayer(media);

            layout.getMediaView().setMediaPlayer(mediaPlayer);

            mediaPlayer.setVolume(layout.getVolumeSlider().getValue());

            mediaPlayer.setOnReady(() -> {
                Duration total = mediaPlayer.getTotalDuration();
                layout.getProgressSlider().setMax(total.toSeconds());
                updateTimeLabel(Duration.ZERO, total);
            });


            mediaPlayer.currentTimeProperty().addListener(
                    (ObservableValue<? extends Duration> obs, Duration oldTime, Duration newTime) -> {
                        if (!isSeeking) {
                            layout.getProgressSlider().setValue(newTime.toSeconds());
                        }
                        Duration total = mediaPlayer.getTotalDuration();
                        updateTimeLabel(newTime, total);
                    });


            mediaPlayer.setOnEndOfMedia(this::playNext);


            mediaPlayer.play();

        } catch (MediaException ex) {
            showError("Kunne ikke spille av filen: " + item.getDisplayName(), ex.getMessage());
        }
     }

     // åpner en filvelger for å importere mediefiler til spillelisten
     private void openFileChooser() {

    FileChooser chooser = new FileChooser();
    chooser.setTitle("Velg mediefiler");

    chooser.getExtensionFilters().addAll(
            new ExtensionFilter("Alle media", "*.mp3", "*.wav", "*.mp4", "*.m4a"),
            new ExtensionFilter("Musikk", "*.mp3", "*.wav", "*.m4a"),
            new ExtensionFilter("Video", "*.mp4")
    );

    // viser filvelgerdialogen og legger til valgte filer i spillelisten
    List<File> files = chooser.showOpenMultipleDialog(null);

    if (files == null || files.isEmpty()) {
        return;
    }

    for (File f : files) {
        MediaItem item = new MediaItem(f.getName(), f.toPath());
        playlist.add(item);
    }

    layout.getPlaylistView().getItems().setAll(playlist);

    if (currentIndex == -1 && !playlist.isEmpty()) {
        currentIndex = 0;
        layout.getPlaylistView().getSelectionModel().select(0);
        playSelectedItem();
    }
}


        // gjenopptar avspillingen av det nåværende medieelementet
    private void resume() {
        if (mediaPlayer != null) {
            mediaPlayer.play();
        } else {
            playSelectedItem();
        }
     }

    // pauser avspillingen av det nåværende medieelementet
    private void pause() {
        if (mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }

    // stopper avspillingen av det nåværende medieelementet
    private void stop() {   
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            layout.getProgressSlider().setValue(0);
            updateTimeLabel(Duration.ZERO, mediaPlayer.getTotalDuration());
        }
    }

    // spiller av neste medieelement i spillelisten
    private void playNext() {
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        layout.getPlaylistView().getSelectionModel().select(currentIndex);
        playSelectedItem();
        }

    // spiller av forrige medieelement i spillelisten
    private void playPrevious() {
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
        layout.getPlaylistView().getSelectionModel().select(currentIndex);
        playSelectedItem();
        }

    // oppdaterer tidslabelen med gjeldende og total varighet
    private void updateTimeLabel(Duration current, Duration total) {
        String cur = formatDuration(current);
        String tot = formatDuration(total);
        layout.getTimeLabel().setText(cur + " / " + tot);
        }

        // formaterer en varighet til mm:ss format
    private String formatDuration(Duration d) {
        if (d == null || d.isUnknown()) {
            return "00:00";
        }
        int seconds = (int) Math.floor(d.toSeconds());
        int mins = seconds / 60;
        int secs = seconds % 60;
        return String.format("%02d:%02d", mins, secs);
        }


    // viser en feilmelding med gitt overskrift og innhold


    private void showError(String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Feil ved avspilling");
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}