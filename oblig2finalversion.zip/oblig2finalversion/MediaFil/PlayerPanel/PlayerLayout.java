package oblig2finalversion.MediaFil.PlayerPanel;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.MediaView;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Layout for mediespilleren.
 * Bygger opp GUI-komponentene og organiserer dem i et BorderPane.
 * Inneholder knapper, lister, skyveknapper og etiketter.
 * Gir tilgang til de ulike komponentene via getter-metoder.
 * 
 */

public class PlayerLayout {

    private final BorderPane root = new BorderPane();
    
    // Listevisning for spillelisten
    private final ListView<MediaItem> playlistView = new ListView<>();
    private final Label nowPlayingLabel = new Label("Now Playing: —");
    private final MediaView mediaView = new MediaView();
    
    // Knapper for kontroll av mediespilleren
    private final Button btnImport = new Button();
    private final Button btnPrev = new Button();
    private final Button btnPlay = new Button();
    private final Button btnPause = new Button();
    private final Button btnStop = new Button();
    private final Button btnNext = new Button();
    
    //Sliders til fremdrift og volum
    private final Slider progressSlider = new Slider();
    private final Slider volumeSlider = new Slider(0, 1, 0.5);

    // Etiketter for tid og volum
    private final Label timeLabel = new Label("00:00 / 00:00");
    private final Label volumeLabel = new Label("Volume:");

    public PlayerLayout() {
        buildLayout();
    }

    /*
     * Bygger opp layouten for mediespilleren.
     */
    private void buildLayout() {
        root.setPadding(new Insets(10));
        root.setStyle("-fx-background-color: #b9b7b7ff;");

        // Oppretter en VBox for spillelisten
        VBox playlistBox = new VBox(8);
        Label playlistLabel = new Label("Playlist");
        playlistLabel.setFont(Font.font("System", FontWeight.BOLD, 14));
        playlistBox.setStyle("-fx-background-color: #ffffffff; -fx-border-color: #cccccc; -fx-border-radius: 6; -fx-background-radius: 6;");
        
        // Konfigurerer ListView for spillelisten
        playlistView.setPrefWidth(220);
        playlistView.setPlaceholder(new Label("Ingen spor lagt til"));
        playlistView.setStyle("-fx-background-color: #d8d1d1ff; opacity: 0.9;");


        // Legger til etiketten og ListView i VBoxen
        playlistBox.getChildren().addAll(playlistLabel, playlistView);
        playlistBox.setPadding(new Insets(05));
        root.setMargin(playlistBox, new Insets(0, 0, 0, 10));
        root.setRight(playlistBox);

        // Oppretter en HBox for topplinjen
        HBox topBar = new HBox();
        nowPlayingLabel.setFont(Font.font("System", FontWeight.BOLD, 16));
        topBar.getChildren().add(nowPlayingLabel);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(0, 0, 10, 0));
        root.setTop(topBar);

        // Senterområdet for medievisning
        mediaView.setPreserveRatio(true);
        mediaView.setFitWidth(600);
        mediaView.setFitHeight(400);
        
        // Pakker MediaView i en StackPane for bedre styling
        StackPane mediaArea = new StackPane(mediaView);
        mediaArea.setStyle("-fx-background-color: black; -fx-border-color: #cccccc; -fx-border-radius: 6; -fx-background-radius: 6;");
        mediaArea.setPadding(new Insets(10));
        // Setter faste dimensjoner for medieområdet
        mediaArea.setPrefHeight(400);
        mediaArea.setPrefWidth(600);
        mediaArea.setMaxHeight(400);
        mediaArea.setMaxWidth(600);
        
        root.setCenter(mediaArea);

        // Oppretter en VBox for bunnområdet
        VBox bottomBox = new VBox(8);
        bottomBox.setPadding(new Insets(10, 0, 0, 0));

        // Oppretter en HBox for knappene
        HBox buttonBar = new HBox( btnImport, btnPrev, btnPlay, btnPause, btnStop, btnNext);
        stillKnapper(btnImport, "btnImport");
        stillKnapper(btnPrev, "btnPrev");
        stillKnapper(btnPlay, "btnPlay");
        stillKnapper(btnPause, "btnPause");
        stillKnapper(btnStop, "btnStop");
        stillKnapper(btnNext, "btnNext");  
        buttonBar.setAlignment(Pos.CENTER);

        // Oppretter en HBox for fremdriftslinjen
        HBox progressBar = new HBox(8);
        progressSlider.setMin(0);
        progressSlider.setMax(1);
        progressSlider.setValue(0);
        progressSlider.setPrefWidth(400);

        progressBar.getChildren().addAll(progressSlider, timeLabel);
        progressBar.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(progressSlider, Priority.ALWAYS);

        // Oppretter en HBox for volumkontrollen
        HBox volumeBar = new HBox(8);
        volumeSlider.setPrefWidth(150);
        volumeBar.getChildren().addAll(volumeLabel, volumeSlider);
        volumeBar.setAlignment(Pos.CENTER_LEFT);

        // Legger til alle boksene i bunnområdet
        bottomBox.getChildren().addAll( progressBar,buttonBar, volumeBar);
        root.setBottom(bottomBox);
    }
     
    // Stiliserer knappene med ikoner og effekter
    private void stillKnapper(Button knapp, String navn) {
        HBox.setMargin(knapp, new Insets(02));
        knapp.setMinHeight(50);
        knapp.setMinWidth(50);
        knapp.setStyle("-fx-background-color: transparent;" +
                "-fx-cursor: hand;" +
                "-fx-background-size: cover;");
        
        var resourceUrl = getClass().getResource("/oblig2finalversion/resursser/icons/" + navn + ".png");
        if (resourceUrl != null) {
            ImageView imageView = new ImageView(new Image(resourceUrl.toExternalForm()));
            imageView.setFitHeight(50);
            imageView.setFitWidth(50);
            knapp.setGraphic(imageView);
        }
        
        knapp.setOnMousePressed(e -> knapp.setOpacity(0.7));
        knapp.setOnMouseReleased(e -> knapp.setOpacity(1.0));
    }

    public BorderPane getRoot() {
        return root;
    }

    public ListView<MediaItem> getPlaylistView() {
        return playlistView;
    }

    public Label getNowPlayingLabel() {
        return nowPlayingLabel;
    }

    public MediaView getMediaView() {
        return mediaView;
    }

    public Button getBtnImport() 
    { return btnImport; }

    public Button getBtnPrev() {
        return btnPrev;
    }

    public Button getBtnPlay() {
        return btnPlay;
    }

    public Button getBtnPause() {
        return btnPause;
    }

    public Button getBtnStop() {
        return btnStop;
    }

    public Button getBtnNext() {
        return btnNext;
    }

    public Slider getProgressSlider() {
        return progressSlider;
    }

    public Slider getVolumeSlider() {
        return volumeSlider;
    }

    public Label getTimeLabel() {
        return timeLabel;
    }
}