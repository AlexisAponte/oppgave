package oblig2finalversion.MediaFil.MultimediaApp;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import oblig2finalversion.MediaFil.PlayerPanel.PlayerController;
import oblig2finalversion.MediaFil.PlayerPanel.PlayerLayout;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        PlayerLayout layout = new PlayerLayout();

        PlayerController controller = new PlayerController(layout);
        controller.init();

        Scene scene = new Scene(layout.getRoot(), 900, 600);
        primaryStage.setTitle("Smart Multimedia Hub");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}